package com.example.aula5

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*
import net.objecthunter.exp4j.ExpressionBuilder
import java.text.SimpleDateFormat
import java.util.*


class MainActivity : AppCompatActivity() {

    private val TAG = MainActivity::class.java.simpleName

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val padrao = "hh:mm:ss"
        val simpleDateFormat = SimpleDateFormat(padrao)
        
        /* Funcionalidade Botões Numericos */
        button_0.setOnClickListener {
            Log.i(TAG, "Click no botão 0")
            if (!text_visor.text.equals("0")) text_visor.append("0")
            Toast.makeText(this, "Metodo: button_0\nHora: ${simpleDateFormat.format(Date())}", Toast.LENGTH_SHORT).show()
        }
        button_1.setOnClickListener {
            Log.i(TAG, "Click no botão 1")
            if (text_visor.text.equals("0")) {
                text_visor.text = "1"
            } else {
                text_visor.append("1")
            }
            Toast.makeText(this, "Metodo: button_1\nHora: ${simpleDateFormat.format(Date())}", Toast.LENGTH_SHORT).show()
        }
        button_2.setOnClickListener {
            Log.i(TAG, "Click no botão 2")
            if (text_visor.text.equals("0")) {
                text_visor.text = "2"
            } else {
                text_visor.append("2")
            }
            Toast.makeText(this, "Metodo: button_2\nHora: ${simpleDateFormat.format(Date())}", Toast.LENGTH_SHORT).show()
        }
        button_3.setOnClickListener {
            Log.i(TAG, "Click no botão 3")
            if (text_visor.text.equals("0")) {
                text_visor.text = "3"
            } else {
                text_visor.append("3")
            }
            Toast.makeText(this, "Metodo: button_3\nHora: ${simpleDateFormat.format(Date())}", Toast.LENGTH_SHORT).show()
        }
        button_4.setOnClickListener {
            Log.i(TAG, "Click no botão 4")
            if (text_visor.text.equals("0")) {
                text_visor.text = "4"
            } else {
                text_visor.append("4")
            }
            Toast.makeText(this, "Metodo: button_4\nHora: ${simpleDateFormat.format(Date())}", Toast.LENGTH_SHORT).show()
        }
        button_5.setOnClickListener {
            Log.i(TAG, "Click no botão 5")
            if (text_visor.text.equals("0")) {
                text_visor.text = "5"
            } else {
                text_visor.append("5")
            }
            Toast.makeText(this, "Metodo: button_5\nHora: ${simpleDateFormat.format(Date())}", Toast.LENGTH_SHORT).show()
        }
        button_6.setOnClickListener {
            Log.i(TAG, "Click no botão 6")
            if (text_visor.text.equals("0")) {
                text_visor.text = "6"
            } else {
                text_visor.append("6")
            }
            Toast.makeText(this, "Metodo: button_6\nHora: ${simpleDateFormat.format(Date())}", Toast.LENGTH_SHORT).show()

        }
        button_period.setOnClickListener {
            Log.i(TAG, "Click no botão .")
            text_visor.append(".")
            Toast.makeText(this, "Metodo: button_period\nHora: ${simpleDateFormat.format(Date())}", Toast.LENGTH_SHORT).show()
        }

        /* Funcionalidade Botões Operações */
        button_adition.setOnClickListener {
            Log.i(TAG, "Click no botão +")
            text_visor.append("+")
            Toast.makeText(this, "Metodo: button_adition\nHora: ${simpleDateFormat.format(Date())}", Toast.LENGTH_SHORT).show()
        }
        button_sub.setOnClickListener {
            Log.i(TAG, "Click no botão -")
            text_visor.append("-")
            Toast.makeText(this, "Metodo: button_sub\nHora: ${simpleDateFormat.format(Date())}", Toast.LENGTH_SHORT).show()
        }
        button_del.setOnClickListener {
            Log.i(TAG, "Click no botão <")
            if (text_visor.text.length == 1) {
                text_visor.text = "0"
            } else {
                text_visor.text = text_visor.text.substring(0, text_visor.text.length - 1)
            }
            Toast.makeText(this, "Metodo: button_del\nHora: ${simpleDateFormat.format(Date())}", Toast.LENGTH_SHORT).show()
        }
        button_C.setOnClickListener {
            Log.i(TAG, "Click no botão C")
            text_visor.text = "0"
            Toast.makeText(this, "Metodo: button_c\nHora: ${simpleDateFormat.format(Date())}", Toast.LENGTH_SHORT).show()
        }
        button_divide.setOnClickListener {
            Log.i(TAG, "Click no botão /")
            text_visor.append("/")
            Toast.makeText(this, "Metodo: button_divide\nHora: ${simpleDateFormat.format(Date())}", Toast.LENGTH_SHORT).show()
        }
        button_equals.setOnClickListener {
            Log.i(TAG, "Click no botão =")
            val expression = ExpressionBuilder(text_visor.text.toString()).build()
            val operacao = text_visor.text
            text_visor.text = expression.evaluate().toString()
            historic.text = "H:\n $operacao = ${text_visor.text}"
            Log.i(TAG, "O resultado da expressão é ${text_visor.text}")
            Toast.makeText(this, "Metodo: button_equals\nHora: ${simpleDateFormat.format(Date())}", Toast.LENGTH_SHORT).show()
        }

    }
}
