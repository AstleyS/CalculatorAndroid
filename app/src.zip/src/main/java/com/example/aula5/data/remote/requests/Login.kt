package com.example.aula5.data.remote.requests


data class Login(private val email: String, private val password: String) {}