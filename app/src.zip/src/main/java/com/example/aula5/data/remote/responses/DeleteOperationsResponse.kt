package com.example.aula5.data.remote.responses

data class DeleteOperationsResponse(private val message: String) {}