package com.example.aula5.data.remote.responses

data class PostOperationResponse(private val message: String) {}