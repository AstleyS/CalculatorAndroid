package com.example.aula5.ui.listeners

interface OnDisplayChanged {

    fun onDisplayChanged(value: String?)

    
}