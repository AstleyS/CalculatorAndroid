package com.example.aula5.ui.listeners

interface OnReceiveLoginAuth {

    fun onReceiveLoginAuth(boolean: Boolean)

}