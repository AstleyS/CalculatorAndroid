package com.example.aula5.ui.listeners

interface OnReceiveToken {

    fun onReceiveToken(token: String?)

}